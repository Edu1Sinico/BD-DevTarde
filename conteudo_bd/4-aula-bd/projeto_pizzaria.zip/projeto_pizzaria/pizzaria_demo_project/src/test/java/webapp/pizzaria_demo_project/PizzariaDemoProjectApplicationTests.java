package webapp.pizzaria_demo_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzariaDemoProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
