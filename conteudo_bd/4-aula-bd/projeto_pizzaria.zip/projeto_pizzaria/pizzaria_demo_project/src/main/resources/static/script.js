function rmvPizza(pizzaName) {
    alert(pizzaName + " removido com sucesso!");
    document.getElementById('pizza-card').style.display = "none";
}