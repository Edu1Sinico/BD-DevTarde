<?php
include 'functions.php';

?>

<?= template_header('Pizzaria Russel') ?>

<div class="content">
    <h2>Início</h2>
    <p>Seja Bem-Vindo!</p>
</div>


<?= template_footer() ?>